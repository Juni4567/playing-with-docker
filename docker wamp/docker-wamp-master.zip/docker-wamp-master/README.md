#Docker-Wamp in windows

######PHP 7 / APACHE / MY SQL virtual machin with docker-compose


##Build the server the first time
	docker-compose build
	
##Run the server
	docker-compose up
	
###If you want the server in background
	docker-compose up -d
	
###Shut down the virtual machine
	docker-compose kill
	